import React, { useState } from 'react';
import './TooltipButton.css';

function TooltipButton({ tips }) {
  const [isTooltipVisible, setTooltipVisible] = useState(false);

  const handleMouseEnter = () => {
    setTooltipVisible(true);
  };

  const handleMouseLeave = () => {
    setTooltipVisible(false);
  };

  return (
    <div className="tooltip-container">
      <button
        className="info-button"
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
      >
        i
      </button>
      {isTooltipVisible && (
        <div className="tooltip">
          <p>Tips : {tips}</p>
        </div>
      )}
    </div>
  );
}

export default TooltipButton;
