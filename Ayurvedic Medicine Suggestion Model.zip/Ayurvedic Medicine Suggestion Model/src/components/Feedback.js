import React, { useState } from 'react';
import './Feedback.css';

const Feedback = () => {
  const [rating, setRating] = useState(0);

  const handleStarClick = (newRating) => {
    setRating(newRating);
    // You can send this rating to your server for feedback processing.
  };
  console.log(rating)
  return (
    <div className='rate'>
      <p>Please rate your experience:</p>
      <div className="star-rating">
        {[1, 2, 3, 4, 5].map((index) => (
          <span
            key={index}
            className={`star ${index <= rating ? 'active' : ''}`}
            onClick={() => handleStarClick(index)}
          >
            &#9733;
          </span>
        ))}
      </div>
    </div>
  );
};

export default Feedback;
