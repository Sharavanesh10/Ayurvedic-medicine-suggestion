import './DynamicSelect.css';
import React, { useState } from "react";
import Select from "react-select";
import "bootstrap/dist/css/bootstrap.css";


const DynamicSelect = ({onUpdate}) => {
  const [selects, setSelects] = useState([{ id: 1, selectedOption: null }]);
  const [options, setOptions] = useState([
    {value: "Abhighataja Vedana and Vata Vikara",label: "Abhighataja Vedana - Pain due to injury"},
    {value: "Abhishyanda",label: "Abhishyanda - Ophthalmic disorders"},
    {value: "Adhamana",label: "Adhamana - Feeling of fullness or heaviness in the abdomen"},
    {value: "Agnidagdha",label: "Agnidagdha - Burning sensation in the body due to aggravated Agni (digestive fire)"},
    {value: "Agnimandya",label: "Agnimandya - Weak digestion"},
    {value: "Ajirna",label: "Ajirna - Indigestion"},
    {value: "Akshepa",label: "Akshepa - Involuntary movements or spasms"},
    {value: "Ama",label: "Ama - Toxins or undigested food"},
    {value: "Amadosha",label: "Amadosha - Disorders caused by Ama (toxins)"},
    {value: "Amajirna",label: "Amajirna - Indigestion of Ama"},
    {value: "Amashula",label: "Amashula - Abdominal pain due to Ama"},
    {value: "Amatisara",label: "Amatisara - Diarrhea caused by Ama"},
    {value: "Amavata",label: "Amavata - Rheumatoid arthritis caused by Ama"},
    {value: "Amlapitta",label: "Amlapitta - Hyperacidity or acid reflux"},
    {value: "Amvata",label: "Amvata - Gouty arthritis caused by Ama"},
    {value: "Anaha",label: "Anaha - Abdominal distension or bloating"},
    {value: "Angasthambha",label: "Angasthambha - Stiffness or rigidity of the body parts"},
    {value: "Angavedana",label: "Angavedana - Body pain or aches"},
    {value: "Anidra",label: "Anidra - Insomnia"},
    {value: "Apachi",label: "Apachi - Boils or skin eruptions"},
    {value: "Apasmara",label: "Apasmara - Epilepsy"},
    {value: "Aptantrak",label: "Aptantrak - Tetanus"},
    {value: "Arbuda",label: "Arbuda - Tumor"},
    {value: "Ardhavbhedaka",label: "Ardhavbhedaka - Hemicrania (type of headache)"},
    {value: "Ardita",label: "Ardhita - Facial paralysis"},
    {value: "Arma",label: "Arma - Hernia"},
    {value: "Arochaka",label: "Arochaka - Anorexia (loss of appetite)"},
    {value: "Arsha",label: "Arsha - Hemorrhoids (piles)"},
    {value: "Arsha Garbhasayaroga",label: "Arsha Garbhasayaroga - Gynecological disorders related to hemorrhoids during pregnancy"},
    {value: "Aruchi",label: "Aruchi - Tastelessness or loss of taste"},
    {value: "Ashmari",label: "Ashmari - Kidney stones"},
    {value: "Asrigdara",label: "Asrigdara - Menorrhagia (excessive menstrual bleeding)"},
    {value: "Asthibhagna",label: "Asthibhagna - Bone fractures"},
    {value: "Asthichyuti",label: "Asthichyuti - Osteoporosis"},
    {value: "Asthiruja",label: "Asthiruja - Swelling of joints"},
    {value: "Atisara",label: "Atisara - Diarrhea"},
    {value: "Avabahuka",label: "Avabahuka - Frozen shoulder"},
    {value: "Badhirya",label: "Badhirya - Deafness"},
    {value: "Bahushosha",label: "Bahushosha - Wasting syndrome"},
    {value: "Balagraha",label: "Balagraha - Possession by evil spirits"},
    {value: "Balakshaya",label: "Balakshaya - Nutritional deficiency in children"},
    {value: "Balaroga",label: "Balaroga - Diseases related to strength and vitality"},
    {value: "BalaShosha",label: "BalaShosha - Wasting of strength and energy"},
    {value: "Balya",label: "Balya - Promoting strength and vitality"},
    {value: "Bhagandar",label: "Bhagandar - Fistula-in-ano (anorectal condition)"},
    {value: "Bhagandara",label: "Bhagandara - Another term for Fistula-in-ano"},
    {value: "Bhrama",label: "Bhrama - Dizziness or vertigo"},
    {value: "Bhru-shankha-KarnaShula",label: "Bhru-shankha-KarnaShula - Pain in the eyebrows, temples, or ears"},
    {value: "Bhutonmada",label: "Bhutonmada - Psychiatric disorders related to possession by spirits"},
    {value: "Budhidaurbalya",label: "Budhidaurbalya - Mental weakness or intellectual impairment"},
    {value: "Charma Vikara",label: "Charma Vikara - Skin diseases"},
    {value: "Charmkila",label: "Charmkila - Skin disorders or lesions"},
    {value: "Chhardi",label: "Chhardi - Vomiting"},
    {value: "Dadru",label: "Dadru - Fungal skin infection (ringworm)"},
    {value: "Dagdha Vrana",label: "Dagdha Vrana - Burn injuries or wounds"},
    {value: "Daha",label: "Daha - Burning sensation"},
    {value: "Danta Roga",label: "Danta Roga - Dental problems or diseases"},
    {value: "Daurbalya",label: "Daurbalya - General weakness or debility"},
    {value: "Dhatukshaya",label: "Dhatukshaya - Tissue depletion or wasting"},
    {value: "Drishtidaurbalya",label: "Drishtidaurbalya - Visual weakness or impaired vision"},
    {value: "Drishtimandya",label: "Drishtimandya - Blurred vision"},
    {value: "Dushtavrana",label: "Dushtavrana - Infected or ulcerated wounds"},
    {value: "Galaganda",label: "Galaganda - Goiter (enlargement of the thyroid gland)"},
    {value: "Galaroga",label: "Galaroga - Diseases related to the throat"},
    {value: "Gandamala",label: "Gandamala - Swelling or lumps in the neck (usually thyroid nodules)"},
    {value: "Garadosha",label: "Garadosha - Poisoning or toxic conditions"},
    {value: "Garavisha",label: "Garavisha - Poisoning by heavy metals or toxins"},
    {value: "Garbhadosha",label: "Garbhadosha - Disorders related to pregnancy"},
    {value: "Grahani",label: "Grahani - Irritable bowel syndrome or a condition affecting the small intestine"},
    {value: "Grahaniroga",label: "Grahaniroga - Diseases related to Grahani"},
    {value: "Granthi",label: "Granthi - A cyst or tumor"},
    {value: "Gridhrasi",label: "Gridhrasi - Sciatica (pain along the sciatic nerve)"},
    {value: "Gudapaka",label: "Gudapaka - Anal fissure"},
    {value: "Gulma",label: "Gulma - Abdominal tumor or lump"},
    {value: "Halimaka",label: "Halimaka - Jaundice"},
    {value: "Hanustambha",label: "Hanustambha - Stiffness or paralysis of the jaw"},
    {value: "Hikka",label: "Hikka - Hiccup"},
    {value: "Hriddaha",label: "Hriddaha - Burning sensation in the heart region"},
    {value: "Hriddaurbalya",label: "Hriddaurbalya - Weakness or debility of the heart"},
    {value: "Hriddrava",label: "Hriddrava - Palpitations or rapid heartbeat"},
    {value: "Hridroga",label: "Hridroga - Heart disease"},
    {value: "Hridya",label: "Hridya - Heart-tonic or substance beneficial for the heart"},
    {value: "Hritshula",label: "Hritshula - Chest pain or angina"},
    {value: "Indralupta",label: "Indralupta - Alopecia areata (hair loss in patches)"},
    {value: "Janghashula",label: "Janghashula - Calf muscle pain or cramps"},
    {value: "Jara",label: "Jara - Aging or old age"},
    {value: "Jirna Pratishaya",label: "Jirna Pratishaya - Chronic rhinitis or nasal congestion"},
    {value: "Jirna Pravahika",label: "Jirna Pravahika - Chronic diarrhea"},
    {value: "JirnaJvara",label: "JirnaJvara - Chronic fever"},
    {value: "Jvara",label: "Jvara - Fever"},
    {value: "Jvaratisara",label: "Jvaratisara - Fever with diarrhea"},
    {value: "Kamala",label: "Kamala - Jaundice or hepatitis"},
    {value: "Kampa",label: "Kampa - Tremors or shaking"},
    {value: "Kandu",label: "Kandu - Itching"},
    {value: "Kandu Visphota",label: "Kandu Visphota - Itching with eruptions or skin lesions"},
    {value: "Kaphaja Vrana",label: "Kaphaja Vrana - Phlegm-related wounds or ulcers"},
    {value: "Kaphavataja Nadivrana",label: "Kaphavataja Nadivrana - Wounds or ulcers due to the combined effects of phlegm and air imbalances"},
    {value: "Karnagutha",label: "Karnagutha - Ear congestion or blockage"},
    {value: "Karnanada",label: "Karnanada - Tinnitus or ringing in the ears"},
    {value: "Karnashula",label: "Karnashula - Earache or ear pain"},
    {value: "Karnasrava",label: "Karnasrava - Otorrhea (discharge from the ears)"},
    {value: "Karshya",label: "Karshya - Emaciation or wasting"},
    {value: "Kasa",label: "Kasa - Cough"},
    {value: "Kastartava",label: "Kastartava - Painful menstruation or dysmenorrhea"},
    {value: "Katigraha",label: "Katigraha - Low back pain or lumbago"},
    {value: "Katishula",label: "Katishula - Pain in the waist or lower back"},
    {value: "Keshapata",label: "Keshapata - Hair loss"},
    {value: "Keshashata",label: "Keshashata - Premature graying of hair"},
    {value: "Khalitya",label: "Khalitya - Baldness"},
    {value: "Khalli",label: "Khalli - Leprosy"},
    {value: "Khanja",label: "Khanja - Limping"},
    {value: "Klaivya",label: "Klaivya - Weakness or debility"},
    {value: "Kotha",label: "Kotha - Fever with delirium"},
    {value: "Krichhrartav",label: "Krichhrartava - Painful menstruation"},
    {value: "Krimi",label: "Krimi - Worm infestation"},
    {value: "Krimiroga",label: "Krimiroga - Diseases caused by parasites or worms"},
    {value: "Kshata",label: "Kshata - Injury or wound"},
    {value: "Kshatakshina",label: "Kshatakshina - Emaciation or weakness"},
    {value: "Kshaya",label: "Kshaya - Debility or wasting"},
    {value: "Kshudrakushtha",label: "Kshudrakushtha - Minor skin diseases"},
    {value: "Kushtha",label: "Kushtha - Leprosy"},
    {value: "Kustha",label: "Kustha - Skin diseases"},
    {value: "Madhumeha",label: "Madhumeha - Diabetes mellitus"},
    {value: "Mahakushtha",label: "Mahakushtha - Severe skin diseases"},
    {value: "Mahavataroga",label: "Mahavataroga - Major diseases"},
    {value: "Malabandha",label: "Malabandha - Constipation"},
    {value: "Malavarodha",label: "Malavarodha - Obstruction of stool"},
    {value: "Manasa Dosha",label: "Manasa Dosha - Mental disorders"},
    {value: "Mandagni",label: "Mandagni - Weak digestive fire"},
    {value: "Manodaurbalya",label: "Manodaurbalya - Mental weakness or debility"},
    {value: "Manodosha",label: "Manodosha - Mental disorders"},
    {value: "Manodvega",label: "Manodvega - Mental agitation or stress"},
    {value: "Manoroga",label: "Manoroga - Mental illnesses"},
    {value: "Manyastambha",label: "Manyastambha - Stiffness of the neck"},
    {value: "Medhya",label: "Medhya - Brain tonic or substances that enhance intellect"},
    {value: "Medoroga",label: "Medoroga - Obesity or diseases related to fat metabolism"},
    {value: "Moha",label: "Moha - Delusion or confusion"},
    {value: "Mukha Roga",label: "Mukha Roga - Oral diseases"},
    {value: "Mukhapaka",label: "Mukhapaka - Oral ulcers or stomatitis"},
    {value: "Mukhdaurgandhya",label: "Mukhdaurgandhya - Bad breath or halitosis"},
    {value: "Murchha",label: "Murchha - Fainting or loss of consciousness"},
    {value: "Mutraghata",label: "Mutraghata - Urinary obstruction"},
    {value: "Mutrakriccha",label: "Mutrakriccha - Dysuria (painful urination)"},
    {value: "Mutrakricchra",label: "Mutrakricchra - Difficulty in passing urine"},
    {value: "Mutraroga",label: "Mutraroga - Urinary diseases"},
    {value: "Mutrashmari",label: "Mutrashmari - Kidney stones or urinary calculi"},
    {value: "Mutrasthila",label: "Mutrasthila - Retention of urine"},
    {value: "Nadi Vrana",label: "Nadi Vrana - Sinus wounds or ulcers"},
    {value: "Netraroga",label: "Netraroga - Eye diseases"},
    {value: "Netravrana",label: "Netravrana - Eye wound or injury"},
    {value: "Ojakshya",label: "Ojakshya - Loss of vitality or vigor"},
    {value: "Padadaha",label: "Padadaha - Burning sensation in the feet"},
    {value: "Pakshaghata",label: "Pakshaghata - Paralysis of one side of the body (hemiplegia)"},
    {value: "Pakshavadha",label: "Pakshavadha - Hemiplegia or paralysis of one side of the body"},
    {value: "Paktishula",label: "Paktishula - Pain in the right hypochondriac region (indicative of liver or gallbladder issues)"},
    {value: "Palitya",label: "Palitya - Premature graying of hair"},
    {value: "Pama",label: "Pama - Lymphadenopathy or swollen lymph nodes"},
    {value: "Pandu",label: "Pandu - Anemia"},
    {value: "Pandu Duarbalya",label: "Pandu Duarbalya - Anemia with weakness"},
    {value: "Pangu",label: "Pangu - Lameness or limping"},
    {value: "Panguvata",label: "Panguvata - Paralysis of one limb"},
    {value: "Parinamashula",label: "Parinamashula - Pain due to dietary indiscretions"},
    {value: "Parinamshula",label: "Parinamshula - Pain due to dietary indiscretions"},
    {value: "Parshvashula",label: "Parshvashula - Pain in the side or flank"},
    {value: "Pinasa",label: "Pinasa - Sinusitis or rhinitis"},
    {value: "Pitta Dushti",label: "Pitta Dushti - Vitiation of pitta (one of the doshas)"},
    {value: "Pitta Jvara",label: "Pitta Jvara - Fever due to pitta vitiation"},
    {value: "Pittaja Netraroga",label: "Pittaja Netraroga - Eye diseases caused by vitiated pitta"},
    {value: "Pittaja Shirahshula",label: "Pittaja Shirahshula - Headache due to vitiated pitta"},
    {value: "Pittajaroga",label: "Pittajaroga - Diseases caused by vitiated pitta"},
    {value: "Pittaroga",label: "Pittaroga - Diseases related to pitta dosha"},
    {value: "Pliha",label: "Pliha - Splenic disorders or spleen-related diseases"},
    {value: "Pliharoga",label: "Pliharoga - Diseases of the spleen"},
    {value: "Pliha-Yakridroga",label: "Pliha-Yakridroga - Diseases of the spleen and liver"},
    {value: "Pradara",label: "Pradara - Menorrhagia (excessive menstrual bleeding)"},
    {value: "Prameha",label: "Prameha - Urinary disorders, including diabetes"},
    {value: "Pramehapidika",label: "Pramehapidika - Boils associated with urinary disorders"},
    {value: "Prasavottara Lakshana",label: "Prasavottara Lakshana - Symptoms after childbirth"},
    {value: "Prasavottararoga",label: "Prasavottararoga - Diseases occurring after childbirth"},
    {value: "Praseka",label: "Praseka - Excessive salivation or sialorrhea"},
    {value: "Pratishyaya",label: "Pratishyaya - Common cold or nasal congestion"},
    {value: "Pravahika",label: "Pravahika - Dysentery"},
    {value: "Prishashula",label: "Prishashula - Pain in the flanks or lumbar region"},
    {value: "Rajayakshma",label: "Rajayakshma - Tuberculosis"},
    {value: "Rajodosha",label: "Rajodosha - Menstrual disorders"},
    {value: "Rajodushti",label: "Rajodushti - Vitiation of menstrual flow"},
    {value: "Rajorodha",label: "Rajorodha - Menstrual obstruction"},
    {value: "Raktadushti",label: "Raktadushti - Blood disorders"},
    {value: "Raktaj Pravahika",label: "Raktaj Pravahika - Dysentery with blood in stools"},
    {value: "Raktajroga",label: "Raktajroga - Diseases related to blood vitiation"},
    {value: "Raktanishthivana",label: "Raktanishthivana - Varicose veins"},
    {value: "Raktapitta",label: "Raktapitta - Bleeding disorders or bleeding tendencies"},
    {value: "Raktapradara",label: "Raktapradara - Abnormal uterine bleeding"},
    {value: "Raktarsha",label: "Raktarsha - Hemorrhoids or piles"},
    {value: "Raktasrava",label: "Raktasrava - Bleeding disorders or abnormal bleeding"},
    {value: "Raktatisara",label: "Raktatisara - Diarrhea with blood in stools"},
    {value: "Rasayana",label: "Rasayana - Rejuvenation therapy or substances that promote longevity and vitality"},
    {value: "Sandhigata Vata",label: "Sandhigata Vata - Osteoarthritis or joint-related Vata disorders"},
    {value: "Sandhigraha",label: "Sandhigraha - Joint stiffness"},
    {value: "SandhiShula",label: "SandhiShula - Joint pain"},
    {value: "Sandhivedana",label: "Sandhivedana - Joint inflammation or pain in the joints"},
    {value: "Sarpadamsha",label: "Sarpadamsha - Snakebite"},
    {value: "Sarva Jvara",label: "Sarva Jvara - All types of fevers"},
    {value: "Sharkara",label: "Sharkara - Sugar or sweets"},
    {value: "Shirahshula",label: "Shirahshula - Headache"},
    {value: "Shirogatavata",label: "Shirogatavata - Vata-related disorders of the head"},
    {value: "Shirokampa",label: "Shirokampa - Tremors or shaking of the head"},
    {value: "Shiroroga",label: "Shiroroga - Diseases of the head"},
    {value: "Shitapitta",label: "Shitapitta - Urticaria or hives"},
    {value: "Shosha",label: "Shosha - Emaciation or wasting"},
    {value: "Shotha",label: "Shotha - Swelling or edema"},
    {value: "Shukrameha",label: "Shukrameha - Sperm-related disorders or conditions affecting semen"},
    {value: "Shula",label: "Shula - Pain"},
    {value: "Shula Yukta Bradhna",label: "Shula Yukta Bradhna - Painful swelling of the testicles"},
    {value: "Shulahara",label: "Shulahara - Pain-relieving"},
    {value: "Shvasa",label: "Shvasa - Respiratory disorders or difficulty in breathing"},
    {value: "Shveta Pradara",label: "Shveta Pradara - White vaginal discharge"},
    {value: "Shvitra",label: "Shvitra - Leucoderma or vitiligo"},
    {value: "Shwetapradara",label: "Shwetapradara - White vaginal discharge"},
    {value: "Smritiand Buddhi Vardhaka",label: "Smritiand Buddhi Vardhaka - Enhancers of memory and intellect"},
    {value: "Smritibhransha",label: "Smritibhransha - Loss of memory"},
    {value: "Smritidaurbalya",label: "Smritidaurbalya - Weakness of memory"},
    {value: "Smritikshaya",label: "Smritikshaya - Memory loss"},
    {value: "Somaroga",label: "Somaroga - Alcohol-related disorders"},
    {value: "Sthanika Shotha",label: "Sthanika Shotha - Localized swelling or edema"},
    {value: "Sthaulya",label: "Sthaulya - Obesity"},
    {value: "Striroga",label: "Striroga - Gynecological disorders"},
    {value: "Sukradosha",label: "Sukradosha - Sperm-related disorders or semen abnormalities"},
    {value: "Suryavarta",label: "Suryavarta - Solar plexus disorder or abdominal colic"},
    {value: "Sutika Vata",label: "Sutika Vata - Postpartum Vata disorders"},
    {value: "Sutikadosha",label: "Sutikadosha - Postpartum disorders"},
    {value: "Sutikaroga",label: "Sutikaroga - Postpartum diseases"},
    {value: "Svarabheda",label: "Svarabheda - Voice disorders or hoarseness"},
    {value: "Svarakshaya",label: "Svarakshaya - Voice loss"},
    {value: "Svarbheda",label: "Svarbheda - Hoarseness of voice"},
    {value: "Timira",label: "Timira - Darkness in vision or loss of sight"},
    {value: "Trikshula",label: "Trikshula - Pain in the eye or ophthalmic pain"},
    {value: "Trisha",label: "Trisha - Thirst"},
    {value: "Trishna",label: "Trishna - Excessive thirst"},
    {value: "Tvak Roga",label: "Tvak Roga - Skin disorders"},
    {value: "Tvak Vikara",label: "Tvak Vikara - Skin abnormalities or dermatological disorders"},
    {value: "Udara",label: "Udara - Abdomen"},
    {value: "Udararoga",label: "Udararoga - Abdominal disorders"},
    {value: "Udarashula",label: "Udarashula - Abdominal pain"},
    {value: "Udarda",label: "Udarda - Urticaria or hives"},
    {value: "Udavarta",label: "Udavarta - Upward movement of Vata in the abdomen"},
    {value: "Udvega",label: "Udvega - Mental stress or anxiety"},
    {value: "Unmada",label: "Unmada - Insanity or madness"},
    {value: "Upadansha",label: "Upadansha - Skin lesions or eruptions"},
    {value: "Urahkshata",label: "Urahkshata - Chest injury or wound"},
    {value: "Urdhvaga Raktapitta",label: "Urdhvaga Raktapitta - Bleeding disorders with upward flow of blood"},
    {value: "Urdhvajatrugataroga",label: "Urdhvajatrugataroga - Disorders related to the upper throat or trachea"},
    {value: "Urushula",label: "Urushula - Testicular pain or orchitis"},
    {value: "Urustambha",label: "Urustambha - Stiffness or spasm of the thigh"},
    {value: "Vandhyaroga",label: "Vandhyaroga - Infertility"},
    {value: "Vandhyatva",label: "Vandhyatva - Sterility or infertility"},
    {value: "Vastigatashula",label: "Vastigatashula - Pain in the bladder region"},
    {value: "Vata Vyadhi",label: "Vata Vyadhi - Diseases related to Vata dosha"},
    {value: "Vatajashula",label: "Vatajashula - Pain due to Vata dosha imbalance"},
    {value: "Vatakaphajaroga",label: "Vatakaphajaroga - Diseases caused by the combination of Vata and Kapha dosha"},
    {value: "VataRakta",label: "VataRakta - Gout (joint disorder related to Vata and blood)"},
    {value: "Vataraktaruja",label: "Vataraktaruja - Painful gout"},
    {value: "Vataroga",label: "Vataroga - Diseases related to Vata dosha"},
    {value: "Vatashlaismika Pratishyaya",label: "Vatashlaismika Pratishyaya - Allergic rhinitis due to Vata"},
    {value: "Vatashonita",label: "Vatashonita - Hemorrhoids caused by Vata dosha"},
    {value: "Vatavikara",label: "Vatavikara - Disorders of Vata dosha"},
    {value: "Vatroga",label: "Vatroga - Diseases related to Vata dosha"},
    {value: "Vibandha",label: "Vibandha - Constipation"},
    {value: "Vicharchika",label: "Vicharchika - Eczema or dermatitis"},
    {value: "Vidagdhajirna",label: "Vidagdhajirna - Digestive disorders with burning sensation"},
    {value: "Vidarika",label: "Vidarika - Genital warts"},
    {value: "Vidradhi",label: "Vidradhi - Abscess or collection of pus"},
    {value: "Vidvibandha",label: "Vidvibandha - Erectile dysfunction or impotence"},
    {value: "Visarpa",label: "Visarpa - A type of skin disease with spreading patches"},
    {value: "Visavikara",label: "Visavikara - Poisoning or toxic conditions"},
    {value: "VishamaJvara",label: "VishamaJvara - Intermittent fever"},
    {value: "VishmaJvara",label: "VishmaJvara - Typhoid fever"},
    {value: "Vishuchika",label: "Vishuchika - Dysentery"},
    {value: "Visuchika",label: "Visuchika - Dysentery"},
    {value: "Vrana",label: "Vrana - Wound or ulcer"},
    {value: "Vranaropana",label: "Vranaropana - Healing of wounds"},
    {value: "Vranashotha",label: "Vranashotha - Swelling of wounds or ulcers"},
    {value: "Vriddhiroga",label: "Vriddhiroga - Age-related diseases"},
    {value: "Vrishya",label: "Vrishya - Aphrodisiac or substances that enhance sexual potency"},
    {value: "Yakshma",label: "Yakshma - Tuberculosis or consumption"},
    {value: "Yonibhransha",label: "Yonibhransha - Injury to the female genital organs"},
    {value: "Yonidosha",label: "Yonidosha - Disorders of the female reproductive system"},
    {value: "Yoniroga",label: "Yoniroga - Gynecological disorders"},
    {value: "Yonishula",label: "Yonishula - Pelvic pain or pain in the female genital region"},
    {value: "Yonivyapat",label: "Yonivyapat - Disorders of the female reproductive organs"}
]);

  const addSelect = () => {
    const unselectedOptions = options.filter(
      (option) =>
        !selects.some(
          (select) =>
            select.selectedOption !== null &&
            select.selectedOption.value === option.value
        )
    );
    if (unselectedOptions.length === 0) {
      return; // No more options to add
    }
    setOptions(unselectedOptions);
    const newSelect = { id: Date.now(), selectedOption: null };
    setSelects([...selects, newSelect]);
  };

  const removeLastSelect = () => {
    if (selects.length === 1) {
      return; // Keep at least one select
    }

    const updatedSelects = [...selects];
    updatedSelects.pop();
    setSelects(updatedSelects);
  };

  const handleChange = (selected, id) => {
    const updatedSelects = selects.map((select) =>
      select.id === id ? { ...select, selectedOption: selected } : select
    );
    setSelects(updatedSelects);
    
    const selectedValues = updatedSelects
      .filter((select) => select.selectedOption !== null)
      .map((select) => select.selectedOption.value);
      console.log(selectedValues)
    onUpdate(selectedValues);
  };

  // const getSelectedValues = () => {
  //   const selectedValues = selects
  //     .filter((select) => select.selectedOption !== null)
  //     .map((select) => select.selectedOption.value);
  //   return selectedValues;
  // };

  return (
    <div className="overall_dynamic_select">
      {selects.map((select, index) => (
        <div key={select.id}>
          <Select
            value={select.selectedOption}
            onChange={(selected) => handleChange(selected, select.id)}
            options={options}
            isSearchable={true}
            placeholder="Symptoms..."
            className='dynamic_select'
            styles={customStyles}
          />
          <div className="btn">
            {index === selects.length - 1 && (
              <button onClick={removeLastSelect} className="remove-button">-</button>
            )}
          </div>
          <br />
        </div>
      ))}
      <div className="btn" style={{ display: "flex", alignItems: "right" }}>
        <button onClick={addSelect} className="add-button">+</button>
      </div>
    </div>
  );
};

const customStyles = {
  control: (provided, state) => ({
    ...provided,
    border: 'none',
    borderRadius: '3px',
    padding: '10px',
    color:'black',
    backgroundColor: state.isFocused ? "rgba(255, 255, 255, 0.5)" : "transparent",
    boxShadow: state.isFocused ? "none" : "none",
    "&::hover": {
      color:'rgba(255, 255, 255, 0.5)'
    }
  }),
  singleValue: provided => ({
    ...provided,
    color: 'black'
  }),
  menu: (provided) => ({
    ...provided,
    backgroundColor: 'rgba(255, 255, 255, 0.5)',
    color:'black'
  }),
  option: (provided, state) => ({
    ...provided,
    backgroundColor: state.isSelected ? '#ea2828' : 'rgba(255, 255, 255, 0.5)',
    color: state.isSelected ? 'white' : 'black',
  
  }),
  placeholder: (defaultStyles) => {
    return {
        ...defaultStyles,
        color: 'black',
    }
}
};

export default DynamicSelect;
