import React from "react";
import './PopupMessage.css';
const schedule = require('node-schedule')

function PopupMessage({ onClose, medicineName, userDetails, emailAddress }) {
  const handleSendEmail = async () => {
    try {
      // Calculate the scheduled time (immediately).
      const startDate = new Date();
      startDate.setMonth(startDate.getMonth() + 3);

      const scheduledDate = new schedule.RecurrenceRule();
      scheduledDate.hour = 7; // 7 AM
      scheduledDate.minute = 0; // 0 minutes past the hour

      const scheduledMon = new schedule.RecurrenceRule();
      scheduledMon.month = startDate.getMonth(); // Set the month of the start date
     scheduledMon.hour = 0; // Midnight
     scheduledMon.minute = 0;


      // Send a POST request to your backend API to send the email.
      const response = await fetch("http://localhost:3001/api/schedule-email", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          selectedMedicine: medicineName,
          userDetails,
          emailAddress,
          scheduledDate,
          scheduledMon
        })
      });

      if (response.ok) {
        console.log("Email sent successfully!");
      } else {
        throw new Error("Failed to send email.");
      }
    } catch (error) {
      console.error(error.message);
      // Handle error and show error message to the user.
    }
  };

  const handleCloseYes = () => {
    // Call the send email function and then close the popup.
    handleSendEmail();
    onClose();
  };

  const handleCloseNo = () => {
    // Call the send email function and then close the popup.
    onClose();
  };

  return (
    <div className="popup-overlay">
      <div className="popup-content">
        <h3>Thank you for choosing {medicineName}!</h3>
        <p>Do you need daily remainder ?</p>
        <button onClick={handleCloseYes} id="yesbtn">Yes</button>
        <button onClick={handleCloseNo}>No</button>
      </div>
    </div>
  );
}

export default PopupMessage;
