import React from 'react';
import { useState } from 'react';
import { useLocation } from 'react-router-dom';
import './ResultPage.css'
import StarRating from './StarRating';
import TooltipButton from './TooltipButton';
import PopupMessage from './PopupMessage';

function ResultPage() {
    const location = useLocation();
    const message = location.state;
    console.log(message)

    const medicineParts = message.Medicine.split(/\n|(?<=[a-z])(?=[A-Z])/);
    let ratingParts = message.Rating.split(' ');
    const ratingPartsArray = ratingParts.map(str => str.trim()).filter(Boolean).map(Number);
    const doctorParts = message.Doctor.split(/(?=Dr\.)/);
    const tipsParts = message.Tips.split('.');
    const profParts = message.Profile.split(' ')
    console.log(medicineParts)
    console.log(ratingParts);
    console.log(ratingPartsArray)
    console.log(tipsParts)
    console.log(doctorParts)
    console.log(profParts)

    const [showPopup, setShowPopup] = useState(false);
    const [selectedMedicine, setSelectedMedicine] = useState('');

    const handleMedicineClick = (medicineName) => {
      setSelectedMedicine(medicineName);
      setShowPopup(true);
      };

  return (
    <div className='rspage'>
      <div className="disclaimer">
        <h2 className='h2'>**Disclaimer**</h2>
        <p className='p'>
        The information provided on this platform serves solely for general
        informational purposes and should not be considered a substitute for
        professional medical advice, diagnosis, or treatment. While Ayurveda
        offers valuable insights, the recommendations here are generic and may
        not suit everyone. Individual results can vary, and we strongly advise
        consulting an Ayurvedic practitioner or healthcare provider for
        personalized guidance. The suggestions provided are not intended to
        replace or undermine advice from licensed professionals, and users
        should always follow their healthcare provider's recommendations. It's
        important to consider the potential interactions and contraindications
        of Ayurvedic remedies with medications and medical conditions and to
        inform your healthcare provider of any Ayurvedic treatments you are
        considering. Moreover, the quality and authenticity of Ayurvedic
        products can vary, so ensure purchases are from reputable sources
        complying with safety and quality standards. This platform does not
        endorse specific products, brands, or practitioners. It's the users'
        responsibility to verify information independently, as Ayurvedic
        knowledge evolves. For personalized Ayurvedic advice, consult with a
        qualified Ayurvedic practitioner. By using this platform, you
        acknowledge that you have read, understood, and agreed to this
        disclaimer. Please contact us with any questions or concerns, and your
        feedback is appreciated as it helps us enhance our services.
        </p>
      </div>
      <h2 className='warmpatient'>Hello {message.Parameters.name}</h2>
      <p>Age: {message.Parameters.age}</p>
      <p>Symptom: {message.Parameters.symptom}</p>
      <p>Choose your Medicine by Clicking on it.</p>
      {medicineParts.map((part, index) => (
        <div key={index} className='medicine' onClick={() => handleMedicineClick(part)}>
            <div className="medicine-info">
                <p className="md">{part}</p><TooltipButton tips={tipsParts[index]} />
                <a className="sd" href={profParts[index]}>by {doctorParts[index]}</a>
            </div>
            <div className="star-rating">
                <StarRating rating={ratingPartsArray[index]} />
            </div>
        </div>
     ))}
     {showPopup && (
        <PopupMessage
          medicineName={selectedMedicine}
          onClose={() => setShowPopup(false)}
          userDetails={message.Parameters}
          emailAddress={message.Parameters.mailid}
        />
      )}
    </div>
  );
}

export default ResultPage;