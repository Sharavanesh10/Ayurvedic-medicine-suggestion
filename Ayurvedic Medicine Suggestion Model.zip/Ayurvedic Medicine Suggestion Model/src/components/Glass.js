import './Glass.css'
import { useState } from 'react'
import axios from 'axios'
import DynamicSelect from './DynamicSelect'
import { useNavigate } from 'react-router-dom'

function Glass() {
  const [name,setName] = useState('')
  const [age,setAge] = useState('')
  const [mailid,setMailid] = useState('')
  const [isValidMail, setIsValidMail] = useState(true);
  let [symptom, setSymptom] = useState('')
  const [meditkn,setMeditkn] = useState('')
  const [message, setMessage] = useState('');
  const navigate=useNavigate();

  const handleSymptomUpdate = (selectedValues) => {
    setSymptom(selectedValues);
  };
  const handleMailidChange = (e) => {
    const enteredMailid = e.target.value;
    
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/i;

    const isEmailValid = emailRegex.test(enteredMailid);

    setIsValidMail(isEmailValid);
    setMailid(enteredMailid);
  };
console.log(message)

  const handleSubmit = (e) => {
    e.preventDefault()
    symptom=symptom.join(",");
    let params = {name,age,mailid,symptom,meditkn}

    axios
      .post('http://localhost:8080/prediction', params)
      .then((res) => {
        const data = res.data.data
        const parameters = JSON.stringify(params)
        const msg = {
            Medicine: data.Medicine,
            Rating:data.Rating,
            Tips:data.TipForMedi,
            Profile:data.Profil,
            Doctor:data.Doct,
            Parameters: JSON.parse(parameters), 
        };
        setMessage(msg);
        console.log(msg)
        navigate('/result',{state:msg});
        reset()
      })
      .catch((error) => alert(`Error: ${error.message}`))
  }

  const handleRateExperienceClick = () => {
    navigate('/feedback');
  };

  const reset = () => {
    setName('')
    setAge('')
    setMailid('')
    setSymptom('')
    setMeditkn('')
  }

  return (
    <div className='container'>
        <div className="glass">
            <form onSubmit={(e) => handleSubmit(e)} className="glass__form">
                <h4 className='head'>Ayurvedic Suggestion Platform</h4>
                <div className="glass__form__group">
                <input
                    id="name"
                    className="glass__form__input"
                    placeholder="Patient name"
                    required
                    autoFocus
                    title="Name of the Patient"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                />
                </div>
                <div className="glass__form__group">
                <input
                    id="age"
                    className="glass__form__input"
                    placeholder="Patient age"
                    required
                    autoFocus
                    min="1"
                    max="100"
                    title="Age of the Patient"
                    type="number"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                />
                </div>
                <div className="glass__form__group" >
                <input
                    id="mailid"
                    className={`glass__form__input ${isValidMail ? '' : 'invalid'}`}
                    placeholder="Gmail ID"
                    required
                    autoFocus
                    title="Mail ID of the Patient"
                    type="text"
                    value={mailid}
                    onChange={handleMailidChange}
                />
                {!isValidMail && (
                  <p className="error-message">Please enter a valid email address.</p>
                )}    
                </div>
                <DynamicSelect onUpdate={handleSymptomUpdate}/>
                <div className="glass__form__group">
                <input
                    id="meditkn"
                    className="glass__form__input"
                    placeholder="Medicine undertaken"
                    required
                    autoFocus
                    title="Medicine undertaken by Patient"
                    type="text"
                    value={meditkn}
                    onChange={(e) => setMeditkn(e.target.value)}
                />
                </div>

                <div className="glass__form__group">
                    <button type="submit" className="glass__form__btn">
                        Suggest
                    </button>
                </div>
            </form>
        </div>
        <div>
            <button onClick={handleRateExperienceClick} className="rate-button">
            Rate Your Experience
            </button>
        </div>
    </div>
  )
}


export default Glass