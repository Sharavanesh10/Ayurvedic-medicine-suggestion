import React from "react";

function StarRating({ rating }) {
  console.log(rating)
  return (
    <div className="star-rating">
      {[...Array(rating)].map((_, index) => (
        <span key={index} className="star filled">
          &#9733;
        </span>
      ))}
    </div>
  );
}

export default StarRating;
