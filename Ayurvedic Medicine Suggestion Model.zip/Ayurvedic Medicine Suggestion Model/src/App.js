import Glass from './components/Glass'
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import ResultPage from './components/ResultPage';
import Feedback from './components/Feedback';


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" exact element={<Glass/>} />
        <Route path="/result" element={<ResultPage/>} />
        <Route path="/feedback" element={<Feedback/>}/>
      </Routes>
    </Router>
  );
}

export default App;