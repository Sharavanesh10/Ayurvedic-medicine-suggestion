import uvicorn
import pickle
from pydantic import BaseModel
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import AMSA
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
import numpy as np
app = FastAPI()
import warnings

with warnings.catch_warnings():
    warnings.filterwarnings("ignore",category=FutureWarning)
    # Load the model and use it


origins = [
    "http://localhost.tiangolo.com",
    "https://localhost.tiangolo.com",
    "http://localhost",
    "http://localhost:8080",
    "http://localhost:3000",
]


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Loading up the trained model
with open('./model/AMSA.pkl', 'rb') as file:
    frm=pickle.load(file)
    fnm=pickle.load(file)
    fsm=pickle.load(file)
    fkm=pickle.load(file)
    fdm=pickle.load(file)
    flm=pickle.load(file)
# Defining the model input types
class Patient(BaseModel):
    name : str
    age : int
    mailid : str
    symptom : str
    meditkn : str

# Setting up the home route
@app.get("/")
def read_root():
    return {"data": "Hello, Welcome Ayurvedic prediction model"}

# Setting up the prediction route
@app.post("/prediction/")
async def get_predict(data: Patient):

        flag=""
        symptom=AMSA.StrtoInp(data.symptom)
        m1=frm.predict(symptom)
        m2=fnm.predict(symptom)
        m3=fsm.predict(symptom)
        m4=fkm.predict(symptom)
        m5=fdm.predict(symptom)
        m6=flm.predict(symptom)
        outp=AMSA.OuptoDict(m1,m2,m3,m4,m5,m6)
        med = list(map(str, list(outp["medi"])))
        fb = list(map(str, list(outp["rate"])))
        tp = list(map(str, list(outp["tipsl"])))
        pf = list(map(str, list(outp["profl"])))
        dn = list(map(str, list(outp["drl"])))
        if(len(med)!=1):
            for elem in med:
                if elem == data.meditkn:
                    med.remove(elem)
        if(len(med)==1):
            s1=''.join(map(str,med))
            if (s1==data.meditkn):
                flag='Increase Same medicine\'s Dose'
            else:
                flag=''.join(map(str,med))
        flag=''.join(map(str,med))
        fb=' '.join(map(str,fb))
        tp=' '.join(map(str,tp))
        pf=' '.join(map(str,pf))
        dn=' '.join(map(str,dn))
        print(pf)
        return {    
                "data": {
                'Medicine':flag,
                'Rating':fb,
                'TipForMedi':tp,
                'Profil':pf,
                'Doct':dn
            }
        }



# Configuring the server host and port
if __name__ == '__main__':
    uvicorn.run(app, port=8080, host='0.0.0.0')