const express = require('express');
const nodemailer = require('nodemailer');
const bodyParser = require('body-parser');
const schedule = require('node-schedule');
const cors = require('cors');

const app = express();
app.use(bodyParser.json());
app.use(cors());

const transporter = nodemailer.createTransport({
  service: 'Gmail', 
  auth: {
    user: 'onlyforproject67@gmail.com',
    pass: 'wooz gtzw hhfa xjxu',
  },
});


const minuteRule = new schedule.RecurrenceRule();
minuteRule.second = 0;


const today = new Date();
const year = today.getFullYear(); 
const month = today.getMonth() + 1; 
const day = today.getDate(); 

const formattedDate = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;


app.post('/api/schedule-email', (req, res) => {
  const { selectedMedicine, userDetails, emailAddress,scheduledDate, scheduledMon } = req.body;

  schedule.scheduleJob(minuteRule, async () => {
    try {
        const emailText=`
      Dear ${userDetails.name},

      I hope this email finds you well. We would like to remind you about taking your prescribed medication, ${selectedMedicine}, as part of your treatment plan.

      **Medicine Details:**
      - Medicine Name: ${selectedMedicine}
      - Dosage: [Dosage]
      - Frequency: [Frequency, e.g., Once a day, Twice a day, etc.]
      

      **Reminder Details:**
      - Today's Scheduled Dose: ${formattedDate} 
      - Instructions: Please take your medication that was prescribed to you.

      Taking your medication as prescribed is essential for your health and well-being. If you have any questions or concerns about your medication or experience any side effects, please don't hesitate to contact your healthcare provider.

      We care about your health, and we are here to support you on your journey to recovery. If you have any questions or need assistance, please feel free to reply to this email or call our office.

      Thank you for your cooperation in following your treatment plan. Wishing you good health and a speedy recovery.

      Best regards,
      SPN Team
    `;

      await transporter.sendMail({
        from: 'onlyforproject67@gmail.com',
        to: emailAddress,
        subject: `Reminder for Medication-${selectedMedicine}`,
        text: emailText,
      });

      console.log(`Email sent for ${selectedMedicine}`);
    } catch (error) {
      console.error(`Failed to send email for ${selectedMedicine}: ${error.message}`);
    }
  });
  schedule.scheduleJob(scheduledMon, async () => {
    try {
        const emailTextMon = `
      Dear ${userDetails.name},

      We hope this email finds you well.

      It has been approximately 3 months since you started your medication. Your health and well-being are important to us, and we would greatly appreciate your feedback on your medication experience.

      **Medication Details:**
      - Medicine Name: ${selectedMedicine}
      - Dosage: [Dosage]
      - Frequency: [Frequency, e.g., Once a day, Twice a day, etc.]

      **Feedback Request:**
      Please take a moment to rate your experience with the medication you've been taking for the past 3 months. Your feedback will help us improve our services and provide better care to you and others.

      ★☆☆☆☆ - Very Dissatisfied
      ★★☆☆☆ - Dissatisfied
      ★★★☆☆ - Neutral
      ★★★★☆ - Satisfied
      ★★★★★ - Very Satisfied

      To submit your rating, simply click on one of the stars above that reflects your satisfaction level.
      [Visit our website to rate your experience](http://localhost:3000/)
      We will respect your valuable feedback. We look forward to hearing from you.

      Best regards,
      SPN Team
    `;


      await transporter.sendMail({
        from: 'onlyforproject67@gmail.com',
        to: emailAddress,
        subject: `Medication Feedback Request`,
        text: emailTextMon,
      });

      console.log(`Email sent for ${selectedMedicine}`);
    } catch (error) {
      console.error(`Failed to send email for ${selectedMedicine}: ${error.message}`);
    }
  });

  res.status(200).send('Email scheduled successfully!');
});

const PORT = 3001;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
