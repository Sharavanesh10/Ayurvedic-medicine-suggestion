import numpy as np
import pandas as pd
from scipy.stats import mode
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn import tree
import warnings

with warnings.catch_warnings():
    warnings.filterwarnings("ignore", category=FutureWarning)
    # Load the model and use it


DATA_PATH = r"E:\Users\npuni\Documents\SCE\SIH 2023\Ayurvedic Medicine Suggestion Model\model\AYUSH AYURVEDIC DT.csv"

data = pd.read_csv(DATA_PATH, encoding='ISO-8859-1').dropna(axis=1)

tipdata=pd.read_csv(r"E:\Users\npuni\Documents\SCE\SIH 2023\Ayurvedic Medicine Suggestion Model\model\Tips.csv", encoding='ISO-8859-1').dropna(axis=1)
profdata=pd.read_csv(r"E:\Users\npuni\Documents\SCE\SIH 2023\Ayurvedic Medicine Suggestion Model\model\DrProfile.csv", encoding='ISO-8859-1')
medicine_counts = data["Medicine"].value_counts()
temp_df = pd.DataFrame({
	"Medicine": medicine_counts.index,
	"Counts": medicine_counts.values
})

encoder = LabelEncoder()
data["Medicine"] = encoder.fit_transform(data["Medicine"])
tipdata["Medicine"] = encoder.fit_transform(tipdata["Medicine"])
profdata["Medicine"] = encoder.fit_transform(profdata["Medicine"])

X = data.iloc[:,:-3]
y = data.iloc[:, -3]
u = data.iloc[:,-2]
v = data.iloc[:,-1]

X_train, X_test, y_train, y_test =train_test_split(
X, y, test_size = 0.3, random_state = 23)

svm_model = SVC()
svm_model.fit(X_train, y_train)
preds = svm_model.predict(X_test)


nb_model = GaussianNB()
nb_model.fit(X_train, y_train)
preds = nb_model.predict(X_test)

rf_model = RandomForestClassifier(random_state=18)
rf_model.fit(X_train, y_train)
preds = rf_model.predict(X_test)

knn_model= KNeighborsClassifier(n_neighbors=1)
knn_model.fit(X_train,y_train)
preds=knn_model.predict(X_test)


dt_model = tree.DecisionTreeClassifier()
dt_model.fit(X_train, y_train)
preds=dt_model.predict(X_test)


lr_model = LogisticRegression(random_state=0)
lr_model.fit(X_train,y_train)
preds=lr_model.predict(X_test)

final_svm_model = SVC()
final_nb_model = GaussianNB()
final_rf_model = RandomForestClassifier(random_state=18)
final_knn_model= KNeighborsClassifier(n_neighbors=1)
final_dt_model= tree.DecisionTreeClassifier()
final_lr_model = LogisticRegression(random_state=0)
final_svm_model.fit(X, y)
final_nb_model.fit(X, y)
final_rf_model.fit(X, y)
final_knn_model.fit(X,y)
final_dt_model.fit(X,y)
final_lr_model.fit(X,y)

test_data = pd.read_csv(r"E:\Users\npuni\Documents\SCE\SIH 2023\Ayurvedic Medicine Suggestion Model\model\AYUSH AYURVEDIC DT.csv", encoding='ISO-8859-1').dropna(axis=1)

test_X = test_data.iloc[:, :-3]
test_Y = encoder.transform(test_data.iloc[:, -3])

svm_preds = final_svm_model.predict(test_X)
nb_preds = final_nb_model.predict(test_X)
rf_preds = final_rf_model.predict(test_X)
knn_preds= final_knn_model.predict(test_X)
dt_preds = final_dt_model.predict(test_X)
lr_preds = final_lr_model.predict(test_X)

symptoms = X.columns.values

symptom_index = {}
for index, value in enumerate(symptoms):
	symptom = " ".join([i for i in value.split("_")])
	symptom_index[symptom] = index

data_dict = {
	"symptom_index":symptom_index,
	"predictions_classes":encoder.classes_
}

def StrtoInp(inp):
	inp = inp.split(",")

	input_data = [0] * len(data_dict["symptom_index"])
	for indic in inp:
		index = data_dict["symptom_index"][indic]
		input_data[index] = 1
		

	input_data = np.array(input_data).reshape(1,-1)
	return input_data

def OuptoDict(r,n,s,k,d,l):
	rf_prediction = data_dict["predictions_classes"][r[0]]
	nb_prediction = data_dict["predictions_classes"][n[0]]
	svm_prediction = data_dict["predictions_classes"][s[0]]
	knn_prediction = data_dict["predictions_classes"][k[0]]
	dt_prediction = data_dict["predictions_classes"][d[0]]
	lr_prediction = data_dict["predictions_classes"][l[0]]
	raw_l=[r[0],n[0],s[0],k[0],d[0],l[0]]
	raw_l=np.unique(raw_l)
	# filtered1 = data[data["Medicine"] == rf_prediction]
	# ratings_for_rf = filtered1["Rating"]
	# filtered2 = data[data["Medicine"] == nb_prediction]
	# ratings_for_nb = filtered2["Rating"]
	# filtered3 = data[data["Medicine"] == svm_prediction]
	# ratings_for_svm = filtered3["Rating"]
	# filtered4 = data[data["Medicine"] == knn_prediction]
	# ratings_for_knn = filtered4["Rating"]
	# filtered5 = data[data["Medicine"] == dt_prediction]
	# ratings_for_dt = filtered5["Rating"]
	# filtered6 = data[data["Medicine"] == lr_prediction]
	# ratings_for_lr = filtered6["Rating"]
    
	l=[rf_prediction,nb_prediction,svm_prediction,knn_prediction,dt_prediction,lr_prediction]
	l=np.unique(l)
	print(l)

	ratings = []
	tipslist=[]
	proflist=[]
	drlist=[]

	for elem in raw_l:
		filter = data[data["Medicine"] == elem]
		
		rating_value = filter["Rating"].values[0]
		ratings.append(int(rating_value))
		
	for item in raw_l:
		fil=tipdata[tipdata["Medicine"]==item]
		if not fil.empty:
			tip_value = fil["TipsFM"].values[0]
			tipslist.append(tip_value)
		else:
			tipslist.append("No tips available")
	
	for dtm in raw_l:
		filt=profdata[profdata["Medicine"]==dtm]
		if not filt.empty:
			prof_value = filt["Link"].values[0]
			doctor_name = filt["Doctor"].values[0]
			proflist.append(prof_value)
			drlist.append(doctor_name)

	print("Ratings:", ratings)
	print("Tips:",tipslist)
	print("Prof:",proflist)
	print("Dr:",drlist)
	resl={
		"medi":l,
		"rate":ratings,
		"tipsl":tipslist,
		"profl":proflist,
		"drl":drlist
	}

	return resl

